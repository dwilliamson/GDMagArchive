/***********************************************************************
	Simple Wave Mixing Demo
	Windows DirectSound(tm) implementation

	This code is Copyright (c) 1996 by Jon Blossom. All Rights Reserved.
 **********************************************************************/

#ifdef _WINDOWS

//**********************************************************************
// System includes

#include <windows.h>
#include <dsound.h>

//**********************************************************************
// Internal functions

void DemoMain(void);

long unsigned GetMillisecondTime(void)
{
	return timeGetTime();
}

//**********************************************************************
// Internal globals

static HWND Window =0;
static HINSTANCE ghInstance = 0;

static LPDIRECTSOUND pDirectSound = 0;
static LPDIRECTSOUNDBUFFER pPrimaryBuffer = 0;
static LPDIRECTSOUNDBUFFER pChannel[4];

//**********************************************************************
// Application entry point

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, LPSTR, int)
{
	// Store this away for future use
	ghInstance = hInstance;

	// Transfer control to the demo
	DemoMain();

	return 0;
}

//**********************************************************************
// Wave playing

void PlayWave(int SampleSize, int SampleRate, short BitsPerSample,
	short ChannelCount, char unsigned* pSample)
{
	// Look for a channel to use to play this sample
	int ChannelToUse = -1;
	for (int Count = 0; Count < 4; ++Count)
	{
		if (!pChannel[Count])
		{
			// This channel isn't in use
			ChannelToUse = Count;
			break;
		}
		else
		{
			DWORD Status;
			HRESULT DSResult = pChannel[Count]->GetStatus(&Status);
			if (DSResult == DS_OK &&
				!(Status & (DSBSTATUS_PLAYING | DSBSTATUS_LOOPING)))
			{
				// This channel has finished - it's OK to use it
				// It would be great to re-use DirectSound
				// buffers instead of re-creating them each
				// time...
				pChannel[Count]->Release();
				pChannel[Count] = 0;
				ChannelToUse = Count;
				break;
			}
		}
	}

	if (ChannelToUse > -1)
	{
		// Found an unused channel...

		// Set up buffer information
		WAVEFORMATEX WaveFormat;
		WaveFormat.wFormatTag = WAVE_FORMAT_PCM;
		WaveFormat.nChannels = ChannelCount;
		WaveFormat.nSamplesPerSec = SampleRate;
		WaveFormat.wBitsPerSample = BitsPerSample;
		WaveFormat.cbSize = 0;

		WaveFormat.nBlockAlign = WaveFormat.nChannels *
			(WaveFormat.wBitsPerSample / 8);
		WaveFormat.nAvgBytesPerSec = WaveFormat.nBlockAlign *
			WaveFormat.nSamplesPerSec;

		// Set up a DirectSound buffer
		DSBUFFERDESC BufferDesc;
		ZeroMemory(&BufferDesc, sizeof(BufferDesc));
		BufferDesc.dwSize = sizeof(BufferDesc);
		BufferDesc.dwFlags = DSBCAPS_STATIC | DSBCAPS_CTRLDEFAULT;
		BufferDesc.dwBufferBytes = SampleSize;
		BufferDesc.lpwfxFormat = &WaveFormat;

		// Create a new buffer using the settings for this wave
		HRESULT DSReturn =
			pDirectSound->CreateSoundBuffer(&BufferDesc,
				&pChannel[ChannelToUse], 0);
		if (DSReturn == DS_OK && pChannel[ChannelToUse])
		{
			// Lock the buffer and copy in the data
			BYTE* pData;
			DWORD DataSize;
			if (pChannel[ChannelToUse]->Lock(0, SampleSize,
				&pData, &DataSize, 0, 0, 0) == DS_OK)
			{
				memcpy(pData, pSample, SampleSize);
				pChannel[ChannelToUse]->Unlock(pData, DataSize, 0, 0);

				// Actually play it!
				pChannel[ChannelToUse]->Play(0, 0, 0);
			}
		}
	}
}

//**********************************************************************
// Sound initialization

int BeginSound(void)
{
	// Create a window to talk to DirectSound
	Window = CreateWindow("STATIC", "DirectSound", WS_POPUP,
		0, 0, 100, 25,
		0, 0, ghInstance, 0);
	if (!Window)
		goto Failure;
	ShowWindow(Window, SW_SHOWNORMAL);
	UpdateWindow(Window);

	// Connect to DirectSound
	DirectSoundCreate(0, &pDirectSound, 0);
	if (!pDirectSound)
		goto Failure;

	// Set up DirectSound for exclusive mode
	HRESULT DSReturn;
	DSReturn = pDirectSound->SetCooperativeLevel(Window,
		DSSCL_EXCLUSIVE);
	if (DSReturn != DS_OK)
		goto Failure;

	// Create the primary buffer
	DSBUFFERDESC BufferDesc;
	ZeroMemory(&BufferDesc, sizeof(BufferDesc));
	BufferDesc.dwSize = sizeof(BufferDesc);
	BufferDesc.dwFlags = DSBCAPS_PRIMARYBUFFER;

	DSReturn = pDirectSound->CreateSoundBuffer(&BufferDesc,
		&pPrimaryBuffer, 0);
	if (DSReturn != DS_OK)
		goto Failure;

	return 1;

Failure:
	return 0;
}

//**********************************************************************
// Sound clean-up

void EndSound(void)
{
	if (Window)
	{
		DestroyWindow(Window);
		Window = 0;
	}

	for (int Count = 0; Count < 4; ++Count)
	{
		if (pChannel[Count])
		{
			pChannel[Count]->Release();
			pChannel[Count] = 0;
		}
	}

	if (pPrimaryBuffer)
	{
		pPrimaryBuffer->Release();
		pPrimaryBuffer = 0;
	}

	if (pDirectSound)
	{
		pDirectSound->Release();
		pDirectSound = 0;
	}
}

#endif // _WINDOWS
