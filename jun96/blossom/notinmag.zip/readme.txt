This archive contains Macintosh and Windows source code referenced
in the article "Full-Screen Graphics for Macintosh and Windows 95"
in Game Developer vol 2 no 8 April/May 1996.

To build this project under Windows (32-bit), you must link with
winmm.lib and ddraw.lib.

To build this project on a Macintosh, you must link with DisplayLib,
part of the Display Manager 2.0. The Display Manager 2.0 development
kit is available from Apple's ftp site, at ftp://ftp.info.apple.com/
Apple.Support.Area/Developer_Services/Development_Kits/
Display_Manager_Development_Kit



All code contained in this archive is Copyright (c) 1996 by
Jonathan Blossom. All Rights Reserved.
