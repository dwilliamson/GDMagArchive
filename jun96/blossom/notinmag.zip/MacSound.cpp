/***********************************************************************
	Simple Wave Mixing Demo
	Macintosh Sound Manager 3.0 implementation

	This code is Copyright (c) 1996 by Jon Blossom. All Rights Reserved.
 **********************************************************************/

#ifndef _WINDOWS

//**********************************************************************
// System includes

#include <Timer.h>
#include <Sound.h>

//**********************************************************************
// Internal functions

void DemoMain(void);

long unsigned GetMillisecondTime(void)
{
	// Get a microsecond-accurate time from the Time Manager
	UnsignedWide Microsecs;
	Microseconds(&Microsecs);

	double Time;
	Time = (double)Microsecs.lo / 1000 +
		(double)Microsecs.hi * ((double)0xFFFFFFFF / 1000.0);
	return (long unsigned)Time;
}

//**********************************************************************
// Internal globals

static SndCallBackUPP pCallbackRoutine = 0;
pascal void SoundCallBack(SndChannelPtr, SndCommand*);

static SoundHeader ChannelHeader[4];
static SndChannelPtr pChannel[4];

//**********************************************************************
// Application entry point

int main()
{
	// Initialize the Mac
	MaxApplZone();
	MoreMasters();
	InitGraf(&qd.thePort);
	InitFonts();
	FlushEvents(everyEvent, 0);
	InitWindows();
	InitMenus();
	InitDialogs(0L);
	InitCursor();

	DemoMain();

	return 0;
}

//**********************************************************************
// Wave playing

void PlayWave(int SampleSize, int SampleRate, short BitsPerSample,
	short ChannelCount, char unsigned* pSample)
{
	// Look for a channel to use to play this sample
	int ChannelToUse = -1;
	for (int Count = 0; Count < 4; ++Count)
	{
		// An available channel is
		// recognized by a null sample pointer
		if (pChannel[Count] && !ChannelHeader[Count].samplePtr)
		{
			ChannelToUse = Count;
			break;
		}
	}

	if (ChannelToUse > -1)
	{
		// Found an unused channel...

		// Set up buffer information
		ChannelHeader[ChannelToUse].length = SampleSize;
		ChannelHeader[ChannelToUse].loopStart = SampleSize;
		ChannelHeader[ChannelToUse].loopEnd = SampleSize;

		switch(SampleRate)
		{
			case 11025:
				ChannelHeader[ChannelToUse].sampleRate = rate11025hz;
				ChannelHeader[ChannelToUse].baseFrequency = rate11025hz;
				break;

			case 22050:
				ChannelHeader[ChannelToUse].sampleRate = rate22050hz;
				ChannelHeader[ChannelToUse].baseFrequency = rate22050hz;
				break;

			case 44100:
				ChannelHeader[ChannelToUse].sampleRate = rate44khz;
				ChannelHeader[ChannelToUse].baseFrequency = rate44khz;
				break;

			default:
				// Unsupported format
				break;
		}

		switch(BitsPerSample)
		{
			case 8:
				ChannelHeader[ChannelToUse].encode = stdSH;
				break;

			case 16:
				ChannelHeader[ChannelToUse].encode = extSH;
				break;

			default:
				// Unsupported format
				break;
		}

		// Set up the sound data to indicate
		// that the channel is playing
		ChannelHeader[ChannelToUse].samplePtr =
			(char*)pSample;

		// Play the sound!
		SndCommand Command;
		Command.cmd = bufferCmd;
		Command.param1 = 0;
		Command.param2 = (long)&ChannelHeader[ChannelToUse];
		SndDoCommand(pChannel[ChannelToUse], &Command, false);

		// Queue up a callback to reset the channel
		// header when finished
		Command.cmd = callBackCmd;
		Command.param1 = 0;
		Command.param2 = (long)&ChannelHeader[ChannelToUse].samplePtr;
		SndDoCommand(pChannel[ChannelToUse], &Command, false);
	}
}

//****************************************************************************
// The sound callback routine
// This will get called back when a channel finishes playing

pascal void SoundCallBack(SndChannelPtr pChannel, SndCommand* pCommand)
{
	// This function gets called when we queue up a
	// callBackCmd above, to indicate that the sample
	// has finished playing.
	//
	// The command's param2 points to the
	// ChannelHeader.samplePtr of the channel that finished,
	// which we zero to indicate that it is no longer playing.
	*((Ptr*)pCommand->param2) = 0;
}

//**********************************************************************
// Sound initialization

int BeginSound(void)
{
	int Success = 0;

	unsigned long SoundManagerVersion = SndSoundManagerVersion();
	if (SoundManagerVersion >= 0x03000000)
	{
		Success = 1;

		// Create a UPP for the sound callback
		pCallbackRoutine = NewSndCallBackProc(SoundCallBack);

		// Initialize channels and channel header info
		int Count;
		for (Count = 0; Count < 4; ++Count)
		{
			ChannelHeader[Count].samplePtr = 0;

			// Register the sound callback
			// as the function to call in response
			// to a callBackCmd
			SndNewChannel(&pChannel[Count], sampledSynth,
				0, pCallbackRoutine);
		}
	}

	return Success;
}

//**********************************************************************
// Sound clean-up

void EndSound(void)
{
	// Clear out all the channels
	int Count;
	for (Count = 0; Count < 4; ++Count)
	{
		if (pChannel[Count])
		{
			SndDisposeChannel(pChannel[Count], true);
			pChannel[Count] = 0;
		}
	}

	// Ditch the callback routine
	if (pCallbackRoutine)
	{
		DisposeRoutineDescriptor(pCallbackRoutine);
		pCallbackRoutine = 0;
	}
}

#endif // not _WINDOWS
