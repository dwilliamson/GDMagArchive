/*****************************************************************************
	Simple Wave Mixing Demo

	This code is Copyright (c) 1996 by Jon Blossom. All Rights Reserved.
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//****************************************************************************
// The simple Wave Mixing API

int BeginSound(void);
void EndSound(void);

void PlayWave(int SampleSize, int SampleRate, short BitsPerSample,
	short ChannelCount, char unsigned* pSample);

// This is stolen from XSplat
long unsigned GetMillisecondTime(void);

//****************************************************************************
// Byte-swapping functions
// We'll be loading PC .wav files, which means they're
// in "Intel" format. On the Mac, then, we'll have to
// do some byte-swapping to get them into "Motorola"
// format.

#ifdef _WINDOWS

inline short unsigned Swap16(short unsigned value)
{
	return value;
}

inline long unsigned Swap32(long unsigned value)
{
	return value;
}

#else

inline short unsigned Swap16(short unsigned value)
{
	return (value & 0xFF) << 8 | (value >> 8);
}

inline long unsigned Swap32(long unsigned value)
{
	return (long unsigned)Swap16(value) << 16 |
		Swap16(value >> 16);
}

#endif

//****************************************************************************
// The cheesy demo

void DemoMain(void)
{
	int SampleSize =0;
	int SampleRate =0;
	short BitsPerSample =0;
	short ChannelCount =0;
	char unsigned* pSample =0;

	// Load a wave file
	FILE* pFile = fopen("sample.wav", "rb");
	if (pFile)
	{
		// We're just going to assume this file is valid

		// Skip the 'RIFF' tag and file size (8 bytes)
		// Skip the 'WAVE' tag (4 bytes)
		fseek(pFile, 12, SEEK_SET);

		// Now read RIFF tags until the end of file
		unsigned long Tag;
		unsigned long Size;
		while (!feof(pFile))
		{
			// Read, watching for file end
			if (fread((char*)&Tag, 1, 4, pFile) == 0)
				break;

			Tag = Swap32(Tag);

			fread((char*)&Size, 1, 4, pFile);
			Size = Swap32(Size);

			if (Tag == 0x20746D66) // The 'fmt ' tag
			{
				// 16-bit PCM flag - assume PCM format
				fseek(pFile, 2, SEEK_CUR);

				// 16-bit Channel Count
				fread((char*)&ChannelCount, 1, 2, pFile);
				ChannelCount = Swap16(ChannelCount);

				// 32-bit Sample Rate
				fread((char*)&SampleRate, 1, 4, pFile);
				SampleRate = Swap32(SampleRate);
				
				// Skip Average bytes per second - (4 bytes)
				// Skip padding - (2 bytes)
				fseek(pFile, 6, SEEK_CUR);

				// 16-bit Bits Per Sample
				fread((char*)&BitsPerSample, 1, 2, pFile);
				BitsPerSample = Swap16(BitsPerSample);

				// Skip whatever's left
				if (Size > 16)
					fseek(pFile, Size - 16, SEEK_CUR);
			}
			else if (Tag == 0x61746164) // The 'data' tag
			{
				// Allocate space and read in the wave

				// NOTE: If this is NOT an 8-bit sample, the sample
				// NOTE: data will have to be swapped on the Mac

				pSample = (char unsigned*)malloc(Size);
				if (pSample)
				{
					SampleSize = Size;
					fread((char*)pSample, 1, Size, pFile);
				}
			}
			else
			{
				// An unknown tag - just skip it
				fseek(pFile, Size, SEEK_CUR);
			}
		}

		fclose(pFile);
	}

	// Now play the wave!
	if (pSample && BeginSound())
	{
		long unsigned Time;

		// (Attempt to) play 8 times
		int PlayCount = 0;
		while(PlayCount < 8)
		{
			PlayWave(SampleSize, SampleRate, BitsPerSample,
				ChannelCount, pSample);
			++PlayCount;

			// Wait 3/4 of a second between plays
			Time = GetMillisecondTime();
			while (GetMillisecondTime() - Time < 750)
				;
		}

		// Wait 5 seconds then quit
		Time = GetMillisecondTime();
		while (GetMillisecondTime() - Time < 5000)
			;

		EndSound();
	}

	// Clean up
	if (pSample)
		free(pSample);
}
