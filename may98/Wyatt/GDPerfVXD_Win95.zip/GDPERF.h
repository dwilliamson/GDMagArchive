// DWIPERF.h - include file for VxD GDPERF

#include <vtoolsc.h>

#define GDPERF_Major		1
#define GDPERF_Minor		0
#define GDPERF_DeviceID		UNDEFINED_DEVICE_ID
#define GDPERF_Init_Order	UNDEFINED_INIT_ORDER


