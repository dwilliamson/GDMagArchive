// DWIPERF.c - main module for VxD DWIPERF

#define   DEVICE_MAIN
#include  "gdperf.h"
#include "winioctl.h"
#undef    DEVICE_MAIN

Declare_Virtual_Device(GDPERF)

DefineControlHandler(DEVICE_INIT, OnDeviceInit);
DefineControlHandler(SYS_DYNAMIC_DEVICE_INIT, OnSysDynamicDeviceInit);
DefineControlHandler(W32_DEVICEIOCONTROL, OnW32Deviceiocontrol);


#define DEVICE_FILE_TYPE 40000
#define IOCTL_WRITE_MSR \
    CTL_CODE( DEVICE_FILE_TYPE, 0x900, METHOD_BUFFERED, FILE_READ_ACCESS )

#define IOCTL_READ_MSR \
    CTL_CODE( DEVICE_FILE_TYPE, 0x901, METHOD_BUFFERED, FILE_READ_ACCESS )


BOOL __cdecl ControlDispatcher(
	DWORD dwControlMessage,
	DWORD EBX,
	DWORD EDX,
	DWORD ESI,
	DWORD EDI,
	DWORD ECX)
{
	START_CONTROL_DISPATCH

		ON_DEVICE_INIT(OnDeviceInit);
		ON_SYS_DYNAMIC_DEVICE_INIT(OnSysDynamicDeviceInit);
		ON_W32_DEVICEIOCONTROL(OnW32Deviceiocontrol);

	END_CONTROL_DISPATCH

	return TRUE;
}


BOOL OnDeviceInit(VMHANDLE hVM, PCHAR CommandTail)
{
	return OnSysDynamicDeviceInit();
}


BOOL OnSysDynamicDeviceInit()
{

	_asm
	{
		push	eax
		_emit	0x0f
		_emit	0x20
		_emit	0xe0			// mov eax,cr4

		// clear bit 2 to enable RDTSC at ring 3. [it should already be clear]
		and		eax, NOT (1<<2)

		// set bit 8 in cr4 to enable RDPMC at ring 3
		or		eax, (1<<8)

		_emit	0x0f
		_emit	0x22
		_emit	0xe0			// mov cr4,eax
		pop		eax
	}

	dprintf("Init successful.\n");

	return TRUE;
}


static int PerfRDMSR(PIOCTLPARAMS pDIOCParams)
{
	DWORD	dw_reg, dw_low, dw_high;

	dprintf("RDMSR..\n");

	// we must have sent at least 4 bytes of INPUT data.
	if ( pDIOCParams->dioc_cbInBuf < 4)
	{
		*pDIOCParams->dioc_bytesret = 0;
		return -1;
	}

	// we must have sent at least 8 bytes of OUTPUT space.
	if ( pDIOCParams->dioc_cbOutBuf < 8)
	{
		*pDIOCParams->dioc_bytesret = 0;
		return -1;
	}

	// get the msr to read
	dw_reg = ((DWORD*)pDIOCParams->dioc_InBuf)[0];

	_asm
	{
		push	eax
		push	ecx
		push	edx

		mov		ecx, dw_reg

		_emit	0x0f
		_emit	0x32			//RDMSR

		mov		dw_low, eax
		mov		dw_high, edx

		pop		edx
		pop		ecx
		pop		eax
	}

	((DWORD*)pDIOCParams->dioc_OutBuf)[0] = dw_low;
	((DWORD*)pDIOCParams->dioc_OutBuf)[1] = dw_high;

	*pDIOCParams->dioc_bytesret = 8;
	
	return DEVIOCTL_NOERROR;
}



static int PerfWRMSR(PIOCTLPARAMS pDIOCParams)
{
	DWORD	dw_reg, dw_low, dw_high;

	dprintf("WRMSR..\n");

	// we must have sent at least 12 bytes of INPUT data.
	if ( pDIOCParams->dioc_cbInBuf < 12)
	{
		*pDIOCParams->dioc_bytesret = 0;
		return -1;
	}


	// get the msr to read
	dw_reg = ((DWORD*)pDIOCParams->dioc_InBuf)[0];
	dw_low = ((DWORD*)pDIOCParams->dioc_InBuf)[1];
	dw_high = ((DWORD*)pDIOCParams->dioc_InBuf)[2];

	_asm
	{
		push	eax
		push	ecx
		push	edx

		mov		ecx, dw_reg
		mov		eax, dw_low
		mov		edx, dw_high

		_emit	0x0f
		_emit	0x30			//WRMSR

		pop		edx
		pop		ecx
		pop		eax
	}

	// writes return 0 bytes so a NULL dest buffer can be passed.
	*pDIOCParams->dioc_bytesret = 0;
	
	return DEVIOCTL_NOERROR;
}





DWORD OnW32Deviceiocontrol(PIOCTLPARAMS p)
{
	switch (p->dioc_IOCtlCode)
	{
	case IOCTL_READ_MSR:
		return PerfRDMSR(p);

	case IOCTL_WRITE_MSR:
		return PerfWRMSR(p);
	}
	return DEVIOCTL_NOERROR;
}
