#include "Windows.h"
#include "WinIOCTL.h"
#include "IOCTLCodes.h"
#include "GDPerformance.h"

//---------------------------------------------------------------------------
// static data
//---------------------------------------------------------------------------
#if PERFORMANCE_PROFILE
static HANDLE	hFile		= NULL;
static BOOL		bGoing		= FALSE;
static int		iProcessor	= 0;
static char		chVendor[13];
#endif

//---------------------------------------------------------------------------
// Open the device driver and detect the processor
//---------------------------------------------------------------------------
BOOL bPSInit(void)
{
#if PERFORMANCE_PROFILE
	OSVERSIONINFO	OS;

	if (bGoing)
		return TRUE;

	//-----------------------------------------------------------------------
	// Get the vendor of the processor
	//-----------------------------------------------------------------------
	memset(&chVendor, 0, sizeof(chVendor) );
	_asm
	{
		mov		eax,0
		_emit	0x0f				//CPUID [vendor]
		_emit	0xa2
		mov		DWORD PTR [chVendor+0], ebx
		mov		DWORD PTR [chVendor+4], edx
		mov		DWORD PTR [chVendor+8], ecx
	}

	if (strcmp(chVendor, "GenuineIntel") != 0)
	{
		bGoing = FALSE;		// not an Intel processor so return false
		return FALSE;
	}

	//-----------------------------------------------------------------------
	// Get the operating system version
	//-----------------------------------------------------------------------
	OS.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
	GetVersionEx(&OS);

	if (OS.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		hFile = CreateFile(						// WINDOWS NT
			 "\\\\.\\GDPERF",
			 GENERIC_READ,
			 0,
			 NULL,
			 OPEN_EXISTING,
			 FILE_ATTRIBUTE_NORMAL,
			 NULL);
	}
	else
	{
		hFile = CreateFile(						// WINDOWS 95
			"\\\\.\\GDPERF.VXD",
			 GENERIC_READ,
			 0,
			 NULL,
			 OPEN_EXISTING,
			 FILE_ATTRIBUTE_NORMAL,
			 NULL);
	}

    if (hFile != INVALID_HANDLE_VALUE )
	{
		//-------------------------------------------------------------------
		// We have successfully opened the device driver, get the family
		// of the processor.
		//-------------------------------------------------------------------
		bGoing = TRUE;
		_asm
		{
			mov		eax,1
			_emit	0x0f 			//CPUID [features]
			_emit	0xa2

			mov		ebx,eax			// Extract the family bits
			shr		ebx,8
			and		ebx,0x0f

			cmp		ebx, 4			// 486 Processor, return an error
			je		short PERR

			cmp		ebx, 5			// Pentium Family
			je		short DONE

			cmp		ebx, 6			// Pentium Pro Family
			je		short DONE
			// If we fall through it must be a processor family above 6.
PERR:		jmp		short ERR
							
DONE:
			mov		iProcessor, ebx
		}

		//-------------------------------------------------------------------
		// We need to write to counter 0 on the pro family to enable both
		// of the performance counters. We write to both so they start in a
		// known state. For the pentium this is not necessary.
		//-------------------------------------------------------------------
		if (iProcessor == PENTIUMPRO_FAMILY)
		{
			__bPSSelectPerformanceEvent(P6_CLOCK,0,TRUE,TRUE);
			__bPSSelectPerformanceEvent(P6_CLOCK,1,TRUE,TRUE);
		}
		return TRUE;
ERR:
		bGoing = FALSE;
		return FALSE;
	}
	return FALSE;
#else
	return FALSE;
#endif
}

//---------------------------------------------------------------------------
// Close the device driver
//---------------------------------------------------------------------------
BOOL bPSClose(void)
{
#if PERFORMANCE_PROFILE
	if (!bGoing)				// driver is not going
		return FALSE;

	if (hFile)					// if we have no driver handle, return FALSE
	{
		if (!CloseHandle(hFile))
		{
			hFile = NULL;
			return FALSE;
		}
		hFile = NULL;
		return TRUE;
	}
	return FALSE;
#else
	return FALSE;
#endif
}

//---------------------------------------------------------------------------
// Select the event to monitor with counter 0
//
BOOL __bPSSelectPerformanceEvent(DWORD dw_event, DWORD dw_counter,
								  BOOL b_user, BOOL b_kernel)
{
#if PERFORMANCE_PROFILE
	BOOL	b_res;

	if (dw_counter>1)		// is the counter valid
		return FALSE;

	if (!bGoing)			// is the driver going??
		return FALSE;

	if ( ((dw_event>>28)&0xF) != (DWORD)iProcessor)
	{
		return FALSE;		// this operation is not for this processor
	}

	if ( (((dw_event & 0x300)>>8) & (dw_counter+1)) == 0 )
	{
		return FALSE;		// this operation is not for this counter
	}

	if (iProcessor == PENTIUM_FAMILY)
	{
		__int64	i64_cesr;
		int	i_kernel_bit,i_user_bit;
		BYTE u1_event = (BYTE)((dw_event & (0x3F0000))>>16);

		if (dw_counter==0)		// the kernel and user mode bits depend on
		{						// counter being used.
			i_kernel_bit = 6;
			i_user_bit = 7;
		}
		else
		{
			i_kernel_bit = 22;
			i_user_bit = 23;
		}

		bPSReadMSR(0x11,&i64_cesr);	// get current P5 event select (cesr)

		// top 32bits of cesr are not valid so ignore them
		i64_cesr &= ((dw_counter == 0)?0xffff0000:0x0000ffff); 
		__bPSWriteMSR(0x11,i64_cesr); 				// stop the counter
		__bPSWriteMSR((dw_counter==0)?0x12:0x13,0);	// clear the p.counter

		// set the user and kernel mode bits
		i64_cesr |= ( b_user?(1<<7):0 ) | ( b_kernel?(1<<6):0 );

		// is this the special P5 value that signals count clocks??
		if (u1_event == 0x3f)
		{
			__bPSWriteMSR(0x11, i64_cesr|0x100);	// Count clocks
		}
		else
		{
			__bPSWriteMSR(0x11, i64_cesr|u1_event);	// Count events
		}
	}
	else if (iProcessor == PENTIUMPRO_FAMILY)
	{
		BYTE u1_event = (BYTE)((dw_event & (0xFF0000))>>16);
		BYTE u1_mask = (BYTE)((dw_event & 0xFF));

		// Event select 0 and 1 are identical.
		b_res = __bPSWriteMSR((dw_counter==0)?0x186:0x187,(u1_event | 
									(b_user?(1<<16):0) | 
									(b_kernel?(1<<17):0) | 
									(1<<22) | (1<<18) | 
									(u1_mask<<8)) );
	}
	else
	{
		return FALSE;
	}

	return b_res;
#else
	return FALSE;
#endif
}

//---------------------------------------------------------------------------
// Read model specific register
//---------------------------------------------------------------------------
BOOL __bPSReadMSR(DWORD dw_reg, __int64* pi64_value)
{
#if PERFORMANCE_PROFILE
	BOOL	b_res;
	DWORD	dw_ret_len;
	if (!bGoing)
		return FALSE;

	b_res = DeviceIoControl
	(
		hFile,						// Handle to device
		(DWORD) IOCTL_READ_MSR,		// IO Control code for Read
		&dw_reg,					// Input Buffer to driver.
		sizeof(DWORD),				// Length of input buffer.
		pi64_value,					// Output Buffer from driver.
		sizeof(__int64),			// Length of output buffer in bytes.
		&dw_ret_len,				// Bytes placed in output buffer.
		NULL						// NULL means wait till op. completes
	);

	if (dw_ret_len != sizeof(__int64))
		b_res = FALSE;

	return b_res;
#else
	return FALSE;
#endif
}

//---------------------------------------------------------------------------
// Write model specific register
//---------------------------------------------------------------------------
BOOL __bPSWriteMSR(DWORD dw_reg, __int64 i64_value)
{
#if PERFORMANCE_PROFILE
	BOOL	b_res;
	DWORD	dw_buffer[3];
	DWORD	dw_ret_len;

	if (!bGoing)
		return FALSE;

	dw_buffer[0]				= dw_reg;			// setup the 12 byte input
	*((__int64*)(&dw_buffer[1]))= i64_value;

	b_res = DeviceIoControl
	(
		hFile,						// Handle to device
		(DWORD) IOCTL_WRITE_MSR,	// IO Control code for Read
		dw_buffer,					// Input Buffer to driver.
		12,							// Length of Input buffer
		NULL,						// Buffer from driver, None for WRMSR
		0,							// Length of output buffer in bytes.
		&dw_ret_len,			// Bytes placed in DataBuffer.
		NULL						// NULL means wait till op. completes.
	);

	if (dw_ret_len!=0)
		b_res = FALSE;

	return b_res;
#else
	return FALSE;
#endif
}

//---------------------------------------------------------------------------
// Return the family of the processor
//---------------------------------------------------------------------------
int __PSGetProcessorFamily(void)
{
#if PERFORMANCE_PROFILE
	return iProcessor;
#else
	return 0;
#endif
}
