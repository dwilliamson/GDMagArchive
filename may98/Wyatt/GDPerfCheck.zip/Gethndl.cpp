#include <windows.h>
#include <stdio.h>

void main(void)
{
	HANDLE hfile;
	OSVERSIONINFO	os;

	//-----------------------------------------------------------------
	// Get the OS and Version info
	//-----------------------------------------------------------------
	os.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
	GetVersionEx(&os);


	//-----------------------------------------------------------------
	// Open the driver on each platform. NOTE the filename changes
	//-----------------------------------------------------------------
	if (os.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// WINDOWS NT
		hfile = CreateFile(
			 "\\\\.\\GDPERF",
			 GENERIC_READ,
			 0,
			 NULL,
			 OPEN_EXISTING,
			 FILE_ATTRIBUTE_NORMAL,
			 NULL);
	}
	else
	{
		//WINDOWS 95
		hfile = CreateFile(
			"\\\\.\\GDPERF.VXD",
			 GENERIC_READ,
			 0,
			 NULL,
			 OPEN_EXISTING,
			 FILE_ATTRIBUTE_NORMAL,
			 NULL);
	}

	//-----------------------------------------------------------------
	// Display the results
	//-----------------------------------------------------------------
	if (hfile != INVALID_HANDLE_VALUE)
	{
		printf("Driver Open: Success..\n");
		if (CloseHandle(hfile))
		{
			printf("Driver Close: Success..\n");
		}
		else
		{
			printf("Driver Close: Failed (Error code %d)..\n", 
				GetLastError());
		}
	}
	else
	{
		printf("Driver Open: Failed (Error code %d)..\n", 
			GetLastError());
	}
}
