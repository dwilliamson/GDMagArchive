/*
 *  Copyright (C) 1995, 1996 Microsoft Corporation. All Rights Reserved.
 *
 *  File: lclib.h
 *
 */

#ifndef __LCLIB_H__
#define __LCLIB_H__

char* LSTRRCHR( const char*, int );
char* LSTRCHR( const char*, int );

#endif

