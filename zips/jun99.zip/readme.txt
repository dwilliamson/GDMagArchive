For updated information about this demo, check out Brian Sharp's homepage at http://www.cs.dartmouth.edu/~bsharp/gdmag/.  Sharp has links
to resources (notably a link to the GLUT libraries) off of his site. 

