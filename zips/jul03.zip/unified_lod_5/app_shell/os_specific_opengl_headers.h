#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

// @Process: Put the mini-windows stuff here instead of
// including windows.h everywhere.

#include <windows.h>
#include <gl/gl.h>              // OpenGL

