1/24/98

This archive contains the header and source file from Nick Bobick's article ("Rotating Objects Using Quaternions", page 34) in the February issue of Game Developer magazine.  

-Editor