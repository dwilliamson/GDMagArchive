About the demonstration program.

This is a test suite to see the methods discussed in the article in
action.  Use the following keys to drive the program:

'u':Adds a unit at the location of the mouse
'p':Switch between path methods
's':Switch between search methods
'd':Show data fields of pathfinding algorithms
'i':Show information on used methods
'+':Make map more dense
'-':Make map less dense
'*':Increase distribution threshold.
'/':Decrease distribution threshold.
' ':Add an obstacle at the location of the mouse.

The method which gives the best results is optimized distributed
bidirectional A*.

The code was compiled using watcom 10.6.

