bool load_jpeg_file(char *filename, unsigned char **bitmap_result, 
                    int *width_result, int *height_result);
